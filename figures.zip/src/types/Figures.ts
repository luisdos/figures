export enum Figure {
  Square,
  Circle,
  Triangle
}
